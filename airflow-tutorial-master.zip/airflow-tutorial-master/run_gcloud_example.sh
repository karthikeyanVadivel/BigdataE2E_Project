#!/bin/bash

docker-compose -f docker-compose-gcloud.yml up --abort-on-container-exit